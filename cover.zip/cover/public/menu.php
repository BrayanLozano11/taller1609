<nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="nav-link fw-bold py-1 px-0 active" aria-current="page" href="inicio.php">inicio</a>
        <a class="nav-link fw-bold py-1 px-0" href="caracteristicas.php">caracteristicas</a>
        <a class="nav-link fw-bold py-1 px-0" href="detalles.php">detalles</a>
        <a class="nav-link fw-bold py-1 px-0" href="soporte.php">soporte</a>
        <a class="nav-link fw-bold py-1 px-0" href="ayuda.php">ayuda</a>
      </nav>